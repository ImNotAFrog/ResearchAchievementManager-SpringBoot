package edu.swjtuhc.enums;

public interface SubDepartment{
    // get set 方法
    public String getName();

    public void setName(String name);

    public String getIndex();

    public void setIndex(String index);
    
    
}