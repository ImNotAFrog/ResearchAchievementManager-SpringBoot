package edu.swjtuhc.serviceImpl;

import java.util.List;

import edu.swjtuhc.model.Achievement;
import edu.swjtuhc.model.RankingRequestMsg;
import edu.swjtuhc.service.RankingService;

public class RankingServiceImpl implements RankingService {

	
	@Override
	public List<Achievement> individual(RankingRequestMsg msg) {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public List<Achievement> department(RankingRequestMsg msg) {
		// TODO Auto-generated method stub
		return null;
	}

}
